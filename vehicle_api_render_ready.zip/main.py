import os
import requests
from fastapi import FastAPI, HTTPException, Header, Query

app = FastAPI(
    title="Vehicle Lookup API",
    version="1.0.0"
)

UPSTREAM_URL = "https://www.renewbuy.com/api/v1/vaahan/registration_number/"
API_KEY = os.getenv("API_KEY", "")

@app.get("/")
def home():
    return {
        "status": True,
        "message": "Vehicle Lookup API is running"
    }

@app.get("/health")
def health():
    return {"status": "healthy"}

@app.get("/vehicle")
def vehicle_lookup(
    regn_no: str = Query(..., min_length=4, max_length=20),
    x_api_key: str = Header(default="")
):
    if not API_KEY:
        raise HTTPException(
            status_code=500,
            detail="API_KEY is not configured on the server"
        )

    if x_api_key != API_KEY:
        raise HTTPException(
            status_code=401,
            detail="Invalid or missing API key"
        )

    registration = regn_no.strip().upper()

    # Only use characters normally found in registration numbers.
    allowed = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789- "
    if any(c not in allowed for c in registration):
        raise HTTPException(
            status_code=400,
            detail="Invalid registration number"
        )

    params = {
        "regn_no": registration,
        "partner_code": "",
        "source": "apex",
        "originData": "false"
    }

    # Deliberately do not expose the cookies/session data from the
    # supplied browser request. If the upstream provider requires
    # authorized credentials, configure them privately as environment
    # variables and only where permitted by the provider.
    headers = {
        "User-Agent": "Mozilla/5.0",
        "Accept": "application/json, text/plain, */*"
    }

    try:
        response = requests.get(
            UPSTREAM_URL,
            params=params,
            headers=headers,
            timeout=20
        )
    except requests.RequestException as exc:
        raise HTTPException(
            status_code=502,
            detail="Upstream service could not be reached"
        ) from exc

    if response.status_code != 200:
        raise HTTPException(
            status_code=502,
            detail=f"Upstream service returned HTTP {response.status_code}"
        )

    try:
        data = response.json()
    except ValueError:
        raise HTTPException(
            status_code=502,
            detail="Upstream service returned a non-JSON response"
        )

    return {
        "success": True,
        "registration_number": registration,
        "data": data
    }
